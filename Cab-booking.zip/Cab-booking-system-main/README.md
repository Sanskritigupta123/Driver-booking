# Cab-booking-system
 A web application where dealers can book drivers through the application for transporting their goods
