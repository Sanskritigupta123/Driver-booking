<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>    
<body>
    <form action="searching_data.php" method="POST">
          <input type="text" name = "Stloc" placeholder="Starting Location">
          <br>
          <input type="text" name = "enloc" placeholder="Ending Location">
          <br>
          <input type="text" name = "truck_cap" placeholder="capacity of truck in kgs">
          <br>
          <button type="submit" name= "submit">submit</button>
    </form>
    
</body>
</html>