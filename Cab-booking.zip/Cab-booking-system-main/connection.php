<?php
    $dbsevername = "localhost";
    $dbusername = "root";
    $dbpassword = "";
    $dbname ="phplessons";
    $connection = mysqli_connect($dbsevername,$dbusername,$dbpassword,$dbname);   
?>

