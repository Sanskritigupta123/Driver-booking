<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "fromto";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
?>